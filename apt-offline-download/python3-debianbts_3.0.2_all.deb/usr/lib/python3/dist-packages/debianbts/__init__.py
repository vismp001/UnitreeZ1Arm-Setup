from debianbts.debianbts import * # noqa
from debianbts.version import __version__ # noqa
