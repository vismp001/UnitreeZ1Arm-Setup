"""PyQt v4 widget for VTK.

This module is a version of the vtk.qt module that requires Qt4.
If you do not specifically require Qt4, then use vtk.qt instead.
"""

__all__ = ['QVTKRenderWindowInteractor']
