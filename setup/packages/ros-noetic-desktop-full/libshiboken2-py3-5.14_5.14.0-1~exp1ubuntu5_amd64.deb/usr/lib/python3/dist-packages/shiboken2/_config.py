shiboken_library_soversion = str(5.14)

version = "5.14.0"
version_info = (5, 14, 0, "", "")

__build_date__ = '2020-04-10T22:28:03+00:00'




__setup_py_package_version__ = '5.14.0'
