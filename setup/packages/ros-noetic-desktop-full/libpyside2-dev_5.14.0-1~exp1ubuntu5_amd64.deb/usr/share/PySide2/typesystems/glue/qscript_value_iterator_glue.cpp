%PYARG_0 = Shiboken::Object::newObject(
             reinterpret_cast<SbkObjectType *>(Shiboken::SbkType< ::QScriptValueIterator >()),
             new QScriptValueIterator(*%CPPSELF), true, true);
