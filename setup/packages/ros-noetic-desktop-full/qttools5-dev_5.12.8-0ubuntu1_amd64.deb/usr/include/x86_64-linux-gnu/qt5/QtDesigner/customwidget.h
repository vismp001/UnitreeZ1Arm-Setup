#ifndef DEPRECATED_HEADER_QtDesigner_customwidget_h
#define DEPRECATED_HEADER_QtDesigner_customwidget_h
#if defined(__GNUC__)
#  warning Header <QtDesigner/customwidget.h> is deprecated. Please include <QtUiPlugin/customwidget.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtDesigner/customwidget.h> is deprecated. Please include <QtUiPlugin/customwidget.h> instead.")
#endif
#include <QtUiPlugin/customwidget.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
