var structExifRational =
[
    [ "denominator", "structExifRational.html#a2c32f17876dd1f86a1869450946be56b", null ],
    [ "numerator", "structExifRational.html#af0b91792fb6f2a858be8ca9ae6795a19", null ]
];