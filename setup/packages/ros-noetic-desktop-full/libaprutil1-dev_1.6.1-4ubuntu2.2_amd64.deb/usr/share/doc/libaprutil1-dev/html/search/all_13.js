var searchData=
[
  ['uri_759',['URI',['../group___a_p_r___util___u_r_i.html',1,'']]],
  ['uuid_20handling_760',['UUID Handling',['../group___a_p_r___u_u_i_d.html',1,'']]],
  ['uptime_761',['uptime',['../structapr__memcache__stats__t.html#aec6db8440a51aabfbfaf2130ec5a78bb',1,'apr_memcache_stats_t']]],
  ['uptime_5fin_5fseconds_762',['uptime_in_seconds',['../structapr__redis__stats__t.html#adaf7a5d550e7d879da211be2dd814573',1,'apr_redis_stats_t']]],
  ['used_5fcpu_5fsys_763',['used_cpu_sys',['../structapr__redis__stats__t.html#a3c4ef66cbf160fe90938d80c34a145ff',1,'apr_redis_stats_t']]],
  ['used_5fcpu_5fuser_764',['used_cpu_user',['../structapr__redis__stats__t.html#ac8091b8aadb01f703801bd1e96299c56',1,'apr_redis_stats_t']]],
  ['used_5fmemory_765',['used_memory',['../structapr__redis__stats__t.html#a293573a28827bca42095a5feb87bcda0',1,'apr_redis_stats_t']]],
  ['user_766',['user',['../structapr__uri__t.html#a2b763f50bec4fda0cf67e5238275b5fd',1,'apr_uri_t']]]
];
