var searchData=
[
  ['i18n_20translation_20library_1409',['I18N translation library',['../group___a_p_r___x_l_a_t_e.html',1,'']]]
];
