var searchData=
[
  ['i18n_20translation_20library_653',['I18N translation library',['../group___a_p_r___x_l_a_t_e.html',1,'']]],
  ['init_654',['init',['../structapr__dbd__driver__t.html#abe128d58439959850b95c8ff8ebd89a1',1,'apr_dbd_driver_t']]],
  ['is_5finitialized_655',['is_initialized',['../structapr__uri__t.html#a6f77dda6db6c31c2c3652f6026ea6b73',1,'apr_uri_t']]],
  ['is_5fmetadata_656',['is_metadata',['../structapr__bucket__type__t.html#a6190ff0225374d9c0bd3205dbcaeb81b',1,'apr_bucket_type_t']]]
];
