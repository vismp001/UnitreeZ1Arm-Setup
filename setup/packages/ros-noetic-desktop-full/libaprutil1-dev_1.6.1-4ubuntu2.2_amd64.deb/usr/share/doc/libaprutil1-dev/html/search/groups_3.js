var searchData=
[
  ['date_20routines_1403',['Date routines',['../group___a_p_r___util___date.html',1,'']]],
  ['dbd_20routines_1404',['DBD routines',['../group___a_p_r___util___d_b_d.html',1,'']]],
  ['dbm_20routines_1405',['DBM routines',['../group___a_p_r___util___d_b_m.html',1,'']]]
];
