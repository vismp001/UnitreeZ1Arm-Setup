//
// Copyright (c) 2018 INRIA
//

#ifndef __pinocchio_deprecation_hpp__
#define __pinocchio_deprecation_hpp__

#include "pinocchio/deprecated.hpp"
#include "pinocchio/deprecated-macros.hpp"
#include "pinocchio/deprecated-namespaces.hpp"

#endif // ifndef __pinocchio_deprecation_hpp__
