#ifndef __DEBUG_C_HPP__
#define __DEBUG_C_HPP__

extern "C" void debug_c(int logfil_c, int ndigit_c, int mgetv0_c,
                        int msaupd_c, int msaup2_c, int msaitr_c, int mseigt_c, int msapps_c, int msgets_c, int mseupd_c,
                        int mnaupd_c, int mnaup2_c, int mnaitr_c, int mneigh_c, int mnapps_c, int mngets_c, int mneupd_c,
                        int mcaupd_c, int mcaup2_c, int mcaitr_c, int mceigh_c, int mcapps_c, int mcgets_c, int mceupd_c);

#endif
