#ifndef SimTK_SIMBODY_SimTKSIMBODY_AUX_H_
#define SimTK_SIMBODY_SimTKSIMBODY_AUX_H_

/** @file
Obsolete -- this header file is obsolete as of Simbody 2.2. This stub 
version remains to allow old programs that included "SimTKsimbody_aux.h" 
to continue to compile for now. This header will be removed in a future 
release; you should just include "Simbody.h". **/

#include "Simbody.h"

#endif // SimTK_SIMBODY_SimTKSIMBODY_AUX_H_
