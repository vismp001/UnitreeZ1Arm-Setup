package Debian::Debhelper::Dh_Version;
$version='12.10ubuntu1';
1