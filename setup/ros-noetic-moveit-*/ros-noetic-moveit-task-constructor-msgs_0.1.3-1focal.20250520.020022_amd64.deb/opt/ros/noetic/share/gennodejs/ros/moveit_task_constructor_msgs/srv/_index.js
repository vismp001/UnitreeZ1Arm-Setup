
"use strict";

let GetSolution = require('./GetSolution.js')

module.exports = {
  GetSolution: GetSolution,
};
