var searchData=
[
  ['random_20functions_2168',['Random Functions',['../group__apr__random.html',1,'']]],
  ['ring_20macro_20implementations_2169',['Ring Macro Implementations',['../group__apr__ring.html',1,'']]],
  ['reader_2fwriter_20lock_20routines_2170',['Reader/Writer Lock Routines',['../group__apr__thread__rwlock.html',1,'']]]
];
