var searchData=
[
  ['internal_20memory_20allocation_1196',['Internal Memory Allocation',['../group__apr__allocator.html',1,'']]],
  ['ip_20multicast_1197',['IP Multicast',['../group__apr__mcast.html',1,'']]],
  ['internal_20apr_20support_20functions_1198',['Internal APR support functions',['../group__apr__support.html',1,'']]],
  ['in_1199',['in',['../structapr__proc__t.html#a914bda8939f9d17c9e2f238683fb994b',1,'apr_proc_t']]],
  ['in_5faddr_1200',['in_addr',['../structin__addr.html',1,'']]],
  ['ind_1201',['ind',['../structapr__getopt__t.html#ab04d49d670f095c3244dc9792b70ff07',1,'apr_getopt_t']]],
  ['index_1202',['index',['../structapr__memnode__t.html#a6188325f9e1cbcafcb0a65b7e41881a1',1,'apr_memnode_t']]],
  ['inode_1203',['inode',['../structapr__finfo__t.html#a73aebb666ddc391d53a871802c27eed6',1,'apr_finfo_t']]],
  ['interleave_1204',['interleave',['../structapr__getopt__t.html#a771dbef87345c731845dd63723fb34db',1,'apr_getopt_t']]],
  ['invoked_1205',['invoked',['../structapr__proc__t.html#a72ed1c58c3f08ffa7202fa80e870cd54',1,'apr_proc_t']]],
  ['ip_20protocol_20definitions_20for_20use_20when_20creating_20sockets_1206',['IP Protocol Definitions for use when creating sockets',['../group___i_p___proto.html',1,'']]],
  ['ipaddr_5flen_1207',['ipaddr_len',['../structapr__sockaddr__t.html#a81be21b2eb968b83ca36183213c99867',1,'apr_sockaddr_t']]],
  ['ipaddr_5fptr_1208',['ipaddr_ptr',['../structapr__sockaddr__t.html#a6e1b71121ada4047acde36c6777b5442',1,'apr_sockaddr_t']]],
  ['is_5fdev_1209',['is_dev',['../structapr__version__t.html#aadc878af1010faa53e365e1142c81ced',1,'apr_version_t']]]
];
