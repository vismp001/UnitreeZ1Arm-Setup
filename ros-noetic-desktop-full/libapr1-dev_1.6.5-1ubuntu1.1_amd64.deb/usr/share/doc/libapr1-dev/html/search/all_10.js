var searchData=
[
  ['stat_20functions_1260',['Stat Functions',['../group__apr__file__stat.html',1,'']]],
  ['shared_20memory_20routines_1261',['Shared Memory Routines',['../group__apr__shm.html',1,'']]],
  ['signal_20handling_1262',['Signal Handling',['../group__apr__signal.html',1,'']]],
  ['skip_20list_20implementation_1263',['Skip list implementation',['../group__apr__skiplist.html',1,'']]],
  ['socket_20option_20definitions_1264',['Socket option definitions',['../group__apr__sockopt.html',1,'']]],
  ['status_20value_20tests_1265',['Status Value Tests',['../group___a_p_r___s_t_a_t_u_s___i_s.html',1,'']]],
  ['string_20routines_1266',['String routines',['../group__apr__strings.html',1,'']]],
  ['snprintf_20implementations_1267',['snprintf implementations',['../group___a_p_r___strings___snprintf.html',1,'']]],
  ['s_1268',['s',['../unionapr__descriptor.html#a39a15be8be084afadfa173810b346f6c',1,'apr_descriptor']]],
  ['s_5faddr_1269',['s_addr',['../structin__addr.html#a1bf09b20f0531edf5da627f712561108',1,'in_addr']]],
  ['sa_1270',['sa',['../structapr__sockaddr__t.html#a6aa3866aed7f527bf4f988b6dc9b5675',1,'apr_sockaddr_t']]],
  ['salen_1271',['salen',['../structapr__sockaddr__t.html#aef1d2a482f85eeab7b6bf0a7732a087a',1,'apr_sockaddr_t']]],
  ['servname_1272',['servname',['../structapr__sockaddr__t.html#a668335161a8347b9a34c600bff80b52f',1,'apr_sockaddr_t']]],
  ['sin_1273',['sin',['../structapr__sockaddr__t.html#a7d5cf0290260c3c448360fc819b28714',1,'apr_sockaddr_t']]],
  ['size_1274',['size',['../structapr__finfo__t.html#a3e47a673c5b82a25a783a732dee6f946',1,'apr_finfo_t::size()'],['../structapr__mmap__t.html#a274aea0906a4b674e1642ac9e81966c7',1,'apr_mmap_t::size()']]],
  ['skip_5fend_1275',['skip_end',['../structapr__getopt__t.html#ae9e7e6eb1576820c7dc6e589cc3a28b7',1,'apr_getopt_t']]],
  ['skip_5fstart_1276',['skip_start',['../structapr__getopt__t.html#a0cd41eedf9ed82bf5d9dcc3491ee67dd',1,'apr_getopt_t']]]
];
