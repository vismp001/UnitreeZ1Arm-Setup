
"use strict";

let GetObjectInformation = require('./GetObjectInformation.js')

module.exports = {
  GetObjectInformation: GetObjectInformation,
};
