#ifndef SPNAV_CONFIG_H_
#define SPNAV_CONFIG_H_

#define USE_X11

#endif	/* SPNAV_CONFIG_H_ */
